import json,time
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

class WeakLP:
 def __init__(self,n):
  self.n=n; self.x={(i,r):i*n+r for i in range(n) for r in range(n)};off=n*n;self.y={}
  for i in range(n):
   for j in range(i+1,n):
    for r in range(n):
     for s in range(n):
      if r!=s:self.y[i,j,r,s]=off;off+=1
  self.nvar=off; er=[];ec=[];ed=[];be=[];ur=[];uc=[];ud=[];bu=[];eq=ub=0
  for i in range(n):
   for r in range(n):er.append(eq);ec.append(self.x[i,r]);ed.append(1.)
   be.append(1.);eq+=1
  for r in range(n):
   for i in range(n):er.append(eq);ec.append(self.x[i,r]);ed.append(1.)
   be.append(1.);eq+=1
  for (i,j,r,s),yv in self.y.items():
   # y - xi <= 0
   ur += [ub,ub]; uc += [yv,self.x[i,r]]; ud += [1.,-1.]; bu.append(0.);ub+=1
   # y - xj <= 0
   ur += [ub,ub]; uc += [yv,self.x[j,s]]; ud += [1.,-1.]; bu.append(0.);ub+=1
   # -y + xi + xj <= 1
   ur += [ub,ub,ub]; uc += [yv,self.x[i,r],self.x[j,s]]; ud += [-1.,1.,1.]; bu.append(1.);ub+=1
  groups=defaultdict(list)
  for (i,j,r,s),v in self.y.items():groups[j-i,s-r].append(v)
  for vs in groups.values():
   for v in vs:ur.append(ub);uc.append(v);ud.append(1.)
   bu.append(1.);ub+=1
  self.Aeq=coo_matrix((ed,(er,ec)),shape=(eq,self.nvar)).tocsr();self.be=np.array(be)
  self.Aub=coo_matrix((ud,(ur,uc)),shape=(ub,self.nvar)).tocsr();self.bu=np.array(bu);self.bounds=[(0,1)]*self.nvar
 def solve(self,p):
  b=list(self.bounds)
  for i,r in enumerate(p):
   for q in range(self.n):b[self.x[i,q]]=(1,1) if q==r else (0,0)
  z=linprog(np.zeros(self.nvar),A_ub=self.Aub,b_ub=self.bu,A_eq=self.Aeq,b_eq=self.be,bounds=b,method='highs')
  return z.status
r=json.load(open('/mnt/data/costas_independent/lp_results.json'))
mods={};out=[]
for idx,x in enumerate(r):
 if x['label']!='dead':continue
 # limit all okay
 n=x['n'];mods.setdefault(n,WeakLP(n)); st=mods[n].solve(x['prefix']);out.append({**x,'weak_status':st,'weak_infeasible':st==2})
 print(n,x['k'],idx,st,flush=True)
json.dump(out,open('/mnt/data/costas_independent/weak_results.json','w'),indent=2)
