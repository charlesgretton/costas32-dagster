#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct Enumerator {
  int n;
  uint64_t rows_used = 0;
  vector<int> p;
  vector<uint64_t> diff_used; // bit e+(n-1), per lag
  uint64_t nodes = 0, count = 0;
  ofstream out;
  Enumerator(int N, const string& path): n(N), p(N,-1), diff_used(N,0), out(path) {}
  void dfs(int col) {
    nodes++;
    if (col==n) {
      count++;
      for(int i=0;i<n;i++){ if(i) out << ','; out << p[i]; }
      out << '\n';
      return;
    }
    for(int r=0;r<n;r++) if(!(rows_used>>r&1ULL)) {
      bool ok=true;
      for(int i=0;i<col;i++) {
        int d=col-i, e=r-p[i], bit=e+n-1;
        if((diff_used[d]>>bit)&1ULL){ok=false;break;}
      }
      if(!ok) continue;
      p[col]=r; rows_used|=1ULL<<r;
      for(int i=0;i<col;i++){int d=col-i,e=r-p[i];diff_used[d]|=1ULL<<(e+n-1);}
      dfs(col+1);
      for(int i=0;i<col;i++){int d=col-i,e=r-p[i];diff_used[d]&=~(1ULL<<(e+n-1));}
      rows_used&=~(1ULL<<r); p[col]=-1;
    }
  }
};
int main(int argc,char**argv){
 if(argc!=3){cerr<<"usage: enumerate n out\n";return 2;}
 int n=stoi(argv[1]); Enumerator E(n,argv[2]); E.dfs(0);
 cerr<<"n="<<n<<" count="<<E.count<<" nodes="<<E.nodes<<"\n";
}
