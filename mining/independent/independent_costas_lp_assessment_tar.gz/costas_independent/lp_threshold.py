import argparse, csv, json, random, time
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

class CostasLP:
    def __init__(self,n,strong=True):
        self.n=n; self.strong=strong
        self.x={(i,r): i*n+r for i in range(n) for r in range(n)}
        off=n*n; self.y={}; self.y_meta=[]
        for i in range(n):
          for j in range(i+1,n):
            for r in range(n):
              for s in range(n):
                if r==s: continue
                self.y[(i,j,r,s)]=off; self.y_meta.append((i,j,r,s)); off+=1
        self.nvar=off
        er=[]; ec=[]; ed=[]; beq=[]
        ur=[]; uc=[]; ud=[]; bub=[]
        eqrow=0; ubrow=0
        # each column one row
        for i in range(n):
          for r in range(n): er.append(eqrow);ec.append(self.x[i,r]);ed.append(1.)
          beq.append(1.);eqrow+=1
        # each row one column
        for r in range(n):
          for i in range(n): er.append(eqrow);ec.append(self.x[i,r]);ed.append(1.)
          beq.append(1.);eqrow+=1
        if strong:
          # pair marginals
          for i in range(n):
            for j in range(i+1,n):
              for r in range(n):
                for s in range(n):
                  if s!=r: er.append(eqrow);ec.append(self.y[i,j,r,s]);ed.append(1.)
                er.append(eqrow);ec.append(self.x[i,r]);ed.append(-1.)
                beq.append(0.);eqrow+=1
              for s in range(n):
                for r in range(n):
                  if r!=s: er.append(eqrow);ec.append(self.y[i,j,r,s]);ed.append(1.)
                er.append(eqrow);ec.append(self.x[j,s]);ed.append(-1.)
                beq.append(0.);eqrow+=1
        else:
          # McCormick inequalities y <= xi, y <= xj, y >= xi+xj-1
          for (i,j,r,s),yv in self.y.items():
            ur += [ubrow,ubrow+1,ubrow+2]; uc += [yv,self.x[i,r], yv,self.x[j,s], yv,self.x[i,r],self.x[j,s]]
            # fix row construction separately to avoid ragged trick
            ud += [1.,-1., 1.,-1., -1.,1.,1.]
            # above row indexes mismatch, rebuild below impossible
            raise NotImplementedError
        # displacement capacity
        groups=defaultdict(list)
        for (i,j,r,s),v in self.y.items(): groups[(j-i,s-r)].append(v)
        for key, vs in groups.items():
          for v in vs: ur.append(ubrow);uc.append(v);ud.append(1.)
          bub.append(1.);ubrow+=1
        self.Aeq=coo_matrix((ed,(er,ec)),shape=(eqrow,self.nvar)).tocsr(); self.beq=np.array(beq)
        self.Aub=coo_matrix((ud,(ur,uc)),shape=(ubrow,self.nvar)).tocsr(); self.bub=np.array(bub)
        self.base_bounds=[(0.,1.)]*self.nvar
    def solve(self,prefix):
        bounds=list(self.base_bounds)
        for i,r in enumerate(prefix):
          for q in range(self.n): bounds[self.x[i,q]]=(1.,1.) if q==r else (0.,0.)
        t=time.time()
        res=linprog(np.zeros(self.nvar), A_ub=self.Aub,b_ub=self.bub,A_eq=self.Aeq,b_eq=self.beq,bounds=bounds,method='highs',options={'presolve':True})
        return res.status, time.time()-t, res.message

def load_catalog(path):
    out=[]
    with open(path) as f:
      for line in f:
        if line.strip(): out.append(tuple(map(int,line.strip().split(','))))
    return out

def native_valid_extend(prefix,n,r):
    c=len(prefix)
    if r in prefix:return False
    used=set()
    for j in range(c):
      d=c-j;e=r-prefix[j]
      # compare with all existing pairs same lag
      for a in range(c-d):
        if prefix[a+d]-prefix[a]==e:return False
    return True

def random_prefix(n,k,rng):
    p=[]
    for c in range(k):
      vals=[r for r in range(n) if native_valid_extend(p,n,r)]
      if not vals:return None
      p.append(rng.choice(vals))
    return tuple(p)

def sample(n,k,catalog,dead_target,live_target,rng):
    pref_live=defaultdict(bool)
    # catalog makes prefix containment exact
    cat_prefix=set(tuple(a[:k]) for a in catalog)
    dead=[];live=[];seen=set();tries=0
    while len(dead)<dead_target or len(live)<live_target:
      tries+=1
      if tries>200000:break
      p=random_prefix(n,k,rng)
      if p is None or p in seen:continue
      seen.add(p)
      if p in cat_prefix:
        if len(live)<live_target:live.append(p)
      elif len(dead)<dead_target:dead.append(p)
    return dead,live,tries

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--seed',type=int,default=20261019);ap.add_argument('--per',type=int,default=20)
 args=ap.parse_args();rng=random.Random(args.seed);records=[]
 for n in [12,13,14]:
  cat=load_catalog(f'/mnt/data/costas_independent/costas_{n}.csv')
  model=CostasLP(n,True)
  print('model',n,'vars',model.nvar,'eq',model.Aeq.shape[0],'ub',model.Aub.shape[0],flush=True)
  ks=sorted(set(max(2,min(n-1,round(n*a))) for a in [0.40,0.45,0.50,0.53,0.55,0.57,0.60,0.63,0.67,0.70]))
  for k in ks:
    dead,live,tries=sample(n,k,cat,args.per,max(5,args.per//4),rng)
    print('sample',n,k,'dead',len(dead),'live',len(live),'tries',tries,flush=True)
    for label,arrs in [('dead',dead),('live',live)]:
      for idx,p in enumerate(arrs):
        st,secs,msg=model.solve(p)
        rec=dict(n=n,k=k,ratio=k/n,label=label,prefix=list(p),lp_status=st,lp_infeasible=(st==2),seconds=secs)
        records.append(rec)
        print(' ',label,idx,'status',st,'sec',round(secs,3),flush=True)
    with open(args.out,'w') as f:json.dump(records,f,indent=2)
 if records:
  with open(args.out,'w') as f:json.dump(records,f,indent=2)
main()
