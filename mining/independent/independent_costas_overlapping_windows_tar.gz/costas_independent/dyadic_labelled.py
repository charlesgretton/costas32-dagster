import itertools, json, math, random
from collections import Counter, defaultdict

BASE='/mnt/data/costas_independent'

def load(n):
    return [tuple(map(int,l.strip().split(','))) for l in open(f'{BASE}/costas_{n}.csv') if l.strip()]

def parity_pattern(p):
    return sum((v&1)<<i for i,v in enumerate(p))

def residue_pattern(p,m): return tuple(v%m for v in p)

def cap_ok_bits(bits,n):
    # Necessary condition retaining each labelled column's output parity.
    # At horizontal lag d, vertical differences of parity q have finite integer capacities.
    # Count pairs by parity of endpoint row labels; compare to number of possible nonzero e of that parity.
    for d in range(1,n):
        cnt=[0,0]
        for i in range(n-d):
            cnt[((bits>>(i+d))^(bits>>i))&1]+=1
        # possible e in [-(n-1),n-1]\{0}, parity q
        caps=[0,0]
        for e in range(-(n-1),n):
            if e: caps[e&1]+=1
        # but at fixed horizontal lag any e possible; uniqueness allows each once
        if cnt[0]>caps[0] or cnt[1]>caps[1]: return False
    return True

def lag_parity_signature(bits,n):
    return tuple(sum((((bits>>(i+d))^(bits>>i))&1)==1 for i in range(n-d)) for d in range(1,n))

def all_balanced_bits(n):
    k=n//2
    for ones in itertools.combinations(range(n),k):
        b=0
        for i in ones:b|=1<<i
        yield b

def analyze(n, random_reps=200, seed=123):
    A=load(n); pats=Counter(parity_pattern(p) for p in A); allp=list(all_balanced_bits(n)); cap=[b for b in allp if cap_ok_bits(b,n)]
    rng=random.Random(seed+n)
    random_cover=[]
    for _ in range(random_reps):
        s=set()
        for __ in range(len(A)):
            vals=list(range(n));rng.shuffle(vals);s.add(parity_pattern(vals))
        random_cover.append(len(s))
    sigs=Counter(lag_parity_signature(b,n) for b in pats)
    # mod-4 patterns and matched random catalogue coverage
    mod4=set(residue_pattern(p,4) for p in A)
    rmod=[]
    for _ in range(min(50,random_reps)):
        s=set()
        for __ in range(len(A)):
            vals=list(range(n));rng.shuffle(vals);s.add(residue_pattern(vals,4))
        rmod.append(len(s))
    return {
      'n':n,'arrays':len(A),'balanced_parity_patterns':len(allp),'costas_parity_patterns':len(pats),
      'cap_survivors':len(cap),'costas_pattern_fraction':len(pats)/len(allp),
      'random_parity_coverage_mean':sum(random_cover)/len(random_cover),
      'random_parity_coverage_min':min(random_cover),'random_parity_coverage_max':max(random_cover),
      'distinct_lag_parity_signatures':len(sigs),
      'costas_mod4_patterns':len(mod4),'random_mod4_coverage_mean':sum(rmod)/len(rmod),
      'top_parity_multiplicities':pats.most_common(10),
      'missing_parity_patterns':[b for b in allp if b not in pats][:50]
    }

def main():
    out=[analyze(n) for n in [12,13,14]]
    json.dump(out,open(f'{BASE}/dyadic_labelled_results.json','w'),indent=2)
    for x in out:
      print('\norder',x['n'])
      for k,v in x.items():
       if k not in ('top_parity_multiplicities','missing_parity_patterns'): print(k,v)
if __name__=='__main__':main()
