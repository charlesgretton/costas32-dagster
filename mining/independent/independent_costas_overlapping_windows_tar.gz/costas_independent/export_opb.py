import argparse, json

def xv(i,r): return f'x_{i}_{r}'
def yv(i,j,r,s): return f'y_{i}_{j}_{r}_{s}'

def terms(items):
    return ' '.join((f'+{c} {v}' if c>=0 else f'{c} {v}') for c,v in items)

def write_opb(n,prefix,path):
    cons=[]
    # placements
    for i in range(n): cons.append(([(1,xv(i,r)) for r in range(n)],'=',1,'column'))
    for r in range(n): cons.append(([(1,xv(i,r)) for i in range(n)],'=',1,'row'))
    # pair marginals
    for i in range(n):
      for j in range(i+1,n):
       for r in range(n):
        a=[(1,yv(i,j,r,s)) for s in range(n) if s!=r]+[(-1,xv(i,r))]
        cons.append((a,'=',0,'marginal_i'))
       for s in range(n):
        a=[(1,yv(i,j,r,s)) for r in range(n) if r!=s]+[(-1,xv(j,s))]
        cons.append((a,'=',0,'marginal_j'))
    # displacement capacities
    groups={}
    for i in range(n):
      for j in range(i+1,n):
       for r in range(n):
        for s in range(n):
         if r==s: continue
         groups.setdefault((j-i,s-r),[]).append((1,yv(i,j,r,s)))
    for q,a in groups.items():cons.append((a,'<=',1,'capacity'))
    # prefix
    for i,r in enumerate(prefix):cons.append(([(1,xv(i,r))],'=',1,'prefix'))
    vars=set(v for a,_,_,_ in cons for _,v in a)
    with open(path,'w') as f:
      f.write(f'* #variable= {len(vars)} #constraint= {len(cons)}\n')
      f.write(f'* Costas order {n}, prefix {prefix}\n')
      for a,op,b,kind in cons:
       f.write(f'* {kind}\n{terms(a)} {op} {b} ;\n')
    return len(vars),len(cons)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,required=True);ap.add_argument('--prefix',required=True);ap.add_argument('--out',required=True)
 a=ap.parse_args();p=list(map(int,a.prefix.split(',')));print(write_opb(a.n,p,a.out))
if __name__=='__main__':main()
