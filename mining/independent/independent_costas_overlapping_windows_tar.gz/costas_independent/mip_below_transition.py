import json,time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from lp_model import CostasLP

records=json.load(open('/mnt/data/costas_independent/lp_results.json'))
out=[]
models={}
for rec in records:
    if rec['label']!='dead' or rec['lp_infeasible'] or rec['n']!=12 or rec['k'] not in (5,6):
        continue
    n=rec['n']; model=models.setdefault(n,CostasLP(n,True))
    lb=np.zeros(model.nvar); ub=np.ones(model.nvar)
    for i,r in enumerate(rec['prefix']):
        for q in range(n):
            v=model.x[i,q]; lb[v]=ub[v]=1.0 if q==r else 0.0
    constraints=[LinearConstraint(model.Aeq,model.beq,model.beq),
                 LinearConstraint(model.Aub,-np.inf*np.ones_like(model.bub),model.bub)]
    t=time.time()
    res=milp(np.zeros(model.nvar),integrality=np.ones(model.nvar),bounds=Bounds(lb,ub),constraints=constraints,
             options={'time_limit':60.0,'presolve':True,'mip_rel_gap':0.0})
    sec=time.time()-t
    item={**rec,'mip_status':int(res.status),'mip_success':bool(res.success),'mip_message':res.message,'mip_seconds':sec,
          'mip_node_count':getattr(res,'mip_node_count',None),'mip_gap':getattr(res,'mip_gap',None)}
    out.append(item)
    print(n,rec['k'],rec['prefix'],'status',res.status,'sec',round(sec,3),'nodes',item['mip_node_count'],res.message,flush=True)
json.dump(out,open('/mnt/data/costas_independent/mip_below_transition.json','w'),indent=2)
