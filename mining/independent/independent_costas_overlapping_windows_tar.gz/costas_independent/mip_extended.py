import json,time,statistics
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from lp_model import CostasLP
R=json.load(open('/mnt/data/costas_independent/lp_results.json'))
selected=[]
# all LP-feasible dead at n=13,14 near/below transition, and live controls n=12..14, max 5 each cell
for n in (12,13,14):
 for k in sorted({x['k'] for x in R if x['n']==n}):
  dead=[x for x in R if x['n']==n and x['k']==k and x['label']=='dead' and not x['lp_infeasible']][:5]
  live=[x for x in R if x['n']==n and x['k']==k and x['label']=='live'][:2]
  selected += dead+live
models={};out=[]
for rec in selected:
 n=rec['n'];M=models.setdefault(n,CostasLP(n,True));lb=np.zeros(M.nvar);ub=np.ones(M.nvar)
 for i,r in enumerate(rec['prefix']):
  for q in range(n):lb[M.x[i,q]]=ub[M.x[i,q]]=1 if q==r else 0
 C=[LinearConstraint(M.Aeq,M.beq,M.beq),LinearConstraint(M.Aub,-np.inf*np.ones_like(M.bub),M.bub)]
 t=time.time();z=milp(np.zeros(M.nvar),integrality=np.ones(M.nvar),bounds=Bounds(lb,ub),constraints=C,options={'time_limit':30.0,'presolve':True,'mip_rel_gap':0.0});sec=time.time()-t
 o={**rec,'mip_status':int(z.status),'mip_seconds':sec,'mip_message':z.message,'mip_nodes':getattr(z,'mip_node_count',None)};out.append(o)
 print(n,rec['k'],rec['label'],'lpinf',rec['lp_infeasible'],'mip',z.status,'sec',round(sec,3),'nodes',o['mip_nodes'],flush=True)
json.dump(out,open('/mnt/data/costas_independent/mip_extended.json','w'),indent=2)
