import json,time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from lp_model import CostasLP
R=json.load(open('/mnt/data/costas_independent/lp_results.json'))
sel=[]
for n,k in [(12,5),(12,6),(13,5),(13,6),(14,6),(14,7)]:
 sel += [x for x in R if x['n']==n and x['k']==k and x['label']=='dead' and not x['lp_infeasible']][:2]
models={};out=[]
for rec in sel:
 n=rec['n'];M=models.setdefault(n,CostasLP(n,True));lb=np.zeros(M.nvar);ub=np.ones(M.nvar)
 for i,r in enumerate(rec['prefix']):
  for q in range(n):lb[M.x[i,q]]=ub[M.x[i,q]]=1 if q==r else 0
 C=[LinearConstraint(M.Aeq,M.beq,M.beq),LinearConstraint(M.Aub,-np.inf*np.ones_like(M.bub),M.bub)]
 for pres in [False,True]:
  t=time.time();z=milp(np.zeros(M.nvar),integrality=np.ones(M.nvar),bounds=Bounds(lb,ub),constraints=C,options={'time_limit':30.,'presolve':pres,'mip_rel_gap':0.});sec=time.time()-t
  o={'n':n,'k':rec['k'],'prefix':rec['prefix'],'presolve':pres,'status':int(z.status),'seconds':sec,'nodes':getattr(z,'mip_node_count',None)};out.append(o)
  print(o,flush=True)
json.dump(out,open('/mnt/data/costas_independent/mip_presolve_ablation.json','w'),indent=2)
