#include <algorithm>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
struct S{
 int n;vector<int>order,p;uint64_t rows=0,nodes=0,sol=0;vector<uint64_t>du;
 S(int N,vector<int>O):n(N),order(O),p(N,-1),du(N,0){}
 void dfs(int z){nodes++;if(z==n){sol++;return;}int c=order[z];
  for(int r=0;r<n;r++)if(!(rows>>r&1ULL)){
   bool ok=true;vector<pair<int,int>> add;
   for(int j=0;j<n;j++)if(p[j]>=0){int a=min(c,j),b=max(c,j),d=b-a,e=(c<j?p[j]-r:r-p[j]),bit=e+n-1;if((du[d]>>bit)&1ULL){ok=false;break;}add.push_back({d,bit});}
   if(!ok)continue;p[c]=r;rows|=1ULL<<r;for(auto [d,b]:add)du[d]|=1ULL<<b;dfs(z+1);for(auto [d,b]:add)du[d]&=~(1ULL<<b);rows&=~(1ULL<<r);p[c]=-1;
  }
 }
};
vector<int> mk(int n,string t){vector<int>o;if(t=="left")for(int i=0;i<n;i++)o.push_back(i);else if(t=="outside")for(int i=0;i<n/2;i++){o.push_back(i);o.push_back(n-1-i);}else if(t=="adjacent")for(int i=0;i<n;i+=2){o.push_back(i);if(i+1<n)o.push_back(i+1);}else if(t=="center"){int l=(n-1)/2,r=n/2;if(n%2)o.push_back(l--);while(l>=0||r<n){if(l>=0)o.push_back(l--);if(r<n)o.push_back(r++);}}return o;}
int main(int argc,char**argv){int n=stoi(argv[1]);string t=argv[2];auto o=mk(n,t);S s(n,o);s.dfs(0);cout<<n<<","<<t<<","<<s.nodes<<","<<s.sol<<",order=";for(int x:o)cout<<x<<":";cout<<"\n";}
