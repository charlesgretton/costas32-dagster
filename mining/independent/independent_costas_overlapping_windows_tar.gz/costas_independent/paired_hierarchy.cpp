#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;

static string encode(const vector<int>& p, bool reflect=false){
  int mn=*min_element(p.begin(),p.end()), mx=*max_element(p.begin(),p.end());
  string s; s.reserve(p.size()*3);
  for(int x:p){int y=reflect ? mx-x : x-mn; s+=to_string(y);s.push_back(',');}
  return s;
}
static string canon(const vector<int>& p){string a=encode(p,false),b=encode(p,true);return min(a,b);} 
struct E{
 int n,maxd; uint64_t rows=0,nodes=0; vector<int>p; vector<uint64_t>du;
 vector<uint64_t> depthCount; vector<unordered_set<string>> shape,shapeRef;
 E(int N,int D):n(N),maxd(D),p(N,-1),du(N,0),depthCount(D+1),shape(D+1),shapeRef(D+1){}
 void dfs(int c){
  nodes++; depthCount[c]++;
  if(c>=2){vector<int>q(p.begin(),p.begin()+c);shape[c].insert(encode(q));shapeRef[c].insert(canon(q));}
  if(c==maxd)return;
  for(int r=0;r<n;r++)if(!(rows>>r&1ULL)){
   bool ok=true;for(int i=0;i<c;i++){int d=c-i,e=r-p[i],b=e+n-1;if((du[d]>>b)&1ULL){ok=false;break;}}
   if(!ok)continue;p[c]=r;rows|=1ULL<<r;for(int i=0;i<c;i++){int d=c-i,e=r-p[i];du[d]|=1ULL<<(e+n-1);}dfs(c+1);for(int i=0;i<c;i++){int d=c-i,e=r-p[i];du[d]&=~(1ULL<<(e+n-1));}rows&=~(1ULL<<r);
  }
 }
};
int main(int argc,char**argv){int n=argc>1?stoi(argv[1]):12;int d=argc>2?stoi(argv[2]):8;E e(n,d);e.dfs(0);cout<<"n,depth,raw_prefixes,translation_shapes,translation_reflection_shapes,raw_per_shape,raw_per_refshape\n";for(int k=2;k<=d;k++)cout<<n<<","<<k<<","<<e.depthCount[k]<<","<<e.shape[k].size()<<","<<e.shapeRef[k].size()<<","<<(double)e.depthCount[k]/e.shape[k].size()<<","<<(double)e.depthCount[k]/e.shapeRef[k].size()<<"\n";}
