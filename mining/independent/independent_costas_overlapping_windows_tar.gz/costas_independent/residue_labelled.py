import itertools,json,math,random,time
from collections import Counter
BASE='/mnt/data/costas_independent'
def load(n):return [tuple(map(int,l.strip().split(','))) for l in open(f'{BASE}/costas_{n}.csv') if l.strip()]
def caps(n,m):
 c=Counter()
 for e in range(-(n-1),n):
  if e:c[e%m]+=1
 return [c[q] for q in range(m)]
def valid(seq,n,m):
 cp=caps(n,m)
 for d in range(1,n):
  c=[0]*m
  for i in range(n-d):c[(seq[i+d]-seq[i])%m]+=1
  if any(c[q]>cp[q] for q in range(m)):return False
 return True
def multiset_sequences(counts):
 n=sum(counts);seq=[0]*n
 def rec(pos):
  if pos==n:yield tuple(seq);return
  for a,c in enumerate(counts):
   if c:
    counts[a]-=1;seq[pos]=a;yield from rec(pos+1);counts[a]+=1
 yield from rec(0)
def analyze(n,m,enumerate_all=True):
 A=load(n); patterns=set(tuple(v%m for v in p) for p in A); counts=[sum(1 for r in range(n) if r%m==a) for a in range(m)]
 total=math.factorial(n)
 for c in counts:total//=math.factorial(c)
 surv=None;t0=time.time()
 if enumerate_all:
  surv=0
  for s in multiset_sequences(counts[:] ):
   if valid(s,n,m):surv+=1
 return {'n':n,'m':m,'arrays':len(A),'row_residue_counts':counts,'all_label_patterns':total,'capacity_survivors':surv,'costas_patterns':len(patterns),'costas_valid':sum(valid(s,n,m) for s in patterns),'seconds':time.time()-t0}
out=[]
for n,m,e in [(12,4,True),(13,4,True),(14,4,False),(12,3,True),(13,3,True),(14,3,False)]:
 x=analyze(n,m,e);out.append(x);print(x,flush=True)
json.dump(out,open(f'{BASE}/residue_labelled_results.json','w'),indent=2)
