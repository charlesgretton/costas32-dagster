import argparse, json, random, time
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

class TripleCostasLP:
    def __init__(self,n=12):
        self.n=n
        self.x={(i,r):i*n+r for i in range(n) for r in range(n)}
        off=n*n
        self.y={}
        for i in range(n):
          for j in range(i+1,n):
            for r in range(n):
              for s in range(n):
                if r!=s:
                  self.y[i,j,r,s]=off; off+=1
        self.z={}
        for i in range(n):
          for j in range(i+1,n):
            for k in range(j+1,n):
              for r in range(n):
                for s in range(n):
                  if s==r: continue
                  for t in range(n):
                    if t==r or t==s: continue
                    self.z[i,j,k,r,s,t]=off; off+=1
        self.nvar=off
        er=[];ec=[];ed=[];be=[];eq=0
        ur=[];uc=[];ud=[];bu=[];ub=0
        # placement bistochastic constraints
        for i in range(n):
          for r in range(n): er.append(eq);ec.append(self.x[i,r]);ed.append(1.)
          be.append(1.);eq+=1
        for r in range(n):
          for i in range(n): er.append(eq);ec.append(self.x[i,r]);ed.append(1.)
          be.append(1.);eq+=1
        # pair marginals to x
        for i in range(n):
          for j in range(i+1,n):
            for r in range(n):
              for s in range(n):
                if s!=r: er.append(eq);ec.append(self.y[i,j,r,s]);ed.append(1.)
              er.append(eq);ec.append(self.x[i,r]);ed.append(-1.)
              be.append(0.);eq+=1
            for s in range(n):
              for r in range(n):
                if r!=s: er.append(eq);ec.append(self.y[i,j,r,s]);ed.append(1.)
              er.append(eq);ec.append(self.x[j,s]);ed.append(-1.)
              be.append(0.);eq+=1
        # triple projections onto each pair
        for i in range(n):
          for j in range(i+1,n):
            for k in range(j+1,n):
              # ij pair, sum t
              for r in range(n):
                for s in range(n):
                  if r==s: continue
                  for t in range(n):
                    if t!=r and t!=s:
                      er.append(eq);ec.append(self.z[i,j,k,r,s,t]);ed.append(1.)
                  er.append(eq);ec.append(self.y[i,j,r,s]);ed.append(-1.)
                  be.append(0.);eq+=1
              # ik pair, sum s
              for r in range(n):
                for t in range(n):
                  if r==t: continue
                  for s in range(n):
                    if s!=r and s!=t:
                      er.append(eq);ec.append(self.z[i,j,k,r,s,t]);ed.append(1.)
                  er.append(eq);ec.append(self.y[i,k,r,t]);ed.append(-1.)
                  be.append(0.);eq+=1
              # jk pair, sum r
              for s in range(n):
                for t in range(n):
                  if s==t: continue
                  for r in range(n):
                    if r!=s and r!=t:
                      er.append(eq);ec.append(self.z[i,j,k,r,s,t]);ed.append(1.)
                  er.append(eq);ec.append(self.y[j,k,s,t]);ed.append(-1.)
                  be.append(0.);eq+=1
        # displacement capacities on pair variables
        groups=defaultdict(list)
        for (i,j,r,s),v in self.y.items(): groups[j-i,s-r].append(v)
        for vs in groups.values():
          for v in vs: ur.append(ub);uc.append(v);ud.append(1.)
          bu.append(1.);ub+=1
        self.Aeq=coo_matrix((ed,(er,ec)),shape=(eq,self.nvar)).tocsr()
        self.beq=np.asarray(be)
        self.Aub=coo_matrix((ud,(ur,uc)),shape=(ub,self.nvar)).tocsr()
        self.bub=np.asarray(bu)
        self.bounds=[(0.,1.)]*self.nvar
        print(json.dumps({'n':n,'vars':self.nvar,'x':len(self.x),'y':len(self.y),'z':len(self.z),'eq':eq,'ub':ub,'eq_nnz':self.Aeq.nnz,'ub_nnz':self.Aub.nnz}),flush=True)
    def solve(self,prefix,time_limit=120):
        b=list(self.bounds)
        for i,r in enumerate(prefix):
          for q in range(self.n): b[self.x[i,q]]=(1.,1.) if q==r else (0.,0.)
        t=time.time()
        z=linprog(np.zeros(self.nvar),A_ub=self.Aub,b_ub=self.bub,A_eq=self.Aeq,b_eq=self.beq,bounds=b,method='highs',options={'presolve':True,'time_limit':time_limit})
        return z,time.time()-t

def loadcat(path):
 return [tuple(map(int,l.strip().split(','))) for l in open(path) if l.strip()]
def legal(p,r):
 c=len(p)
 if r in p:return False
 for j in range(c):
  d=c-j;e=r-p[j]
  for a in range(c-d):
   if p[a+d]-p[a]==e:return False
 return True
def walk(n,k,rng):
 p=[]
 for c in range(k):
  v=[r for r in range(n) if legal(p,r)]
  if not v:return None
  p.append(rng.choice(v))
 return tuple(p)
def sample(cat,k,nd,nl,rng):
 live_set={a[:k] for a in cat};D=[];L=[];seen=set();tries=0
 while len(D)<nd or len(L)<nl:
  tries+=1
  if tries>500000:break
  p=walk(12,k,rng)
  if p is None or p in seen:continue
  seen.add(p)
  if p in live_set:
   if len(L)<nl:L.append(p)
  elif len(D)<nd:D.append(p)
 return D,L,tries

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--per',type=int,default=5);ap.add_argument('--seed',type=int,default=120316);a=ap.parse_args()
 rng=random.Random(a.seed);cat=loadcat('/mnt/data/costas_independent/costas_12.csv');M=TripleCostasLP(12);out=[]
 # LP2 results map for comparison when available
 base=json.load(open('/mnt/data/costas_independent/lp_results.json'))
 base_prefix={tuple(x['prefix']):x for x in base if x['n']==12}
 for k in [4,5,6,7]:
  D,L,tr=sample(cat,k,a.per,max(2,a.per//2),rng)
  print('sample',k,len(D),len(L),'tries',tr,flush=True)
  for label,A in [('dead',D),('live',L)]:
   for p in A:
    z,sec=M.solve(p)
    rec={'n':12,'k':k,'ratio':k/12,'label':label,'prefix':list(p),'triple_status':int(z.status),'triple_infeasible':z.status==2,'seconds':sec,'message':z.message}
    if p in base_prefix:rec['lp2_infeasible']=base_prefix[p]['lp_infeasible']
    out.append(rec);print(label,k,p,'status',z.status,'sec',round(sec,3),flush=True)
    json.dump(out,open(a.out,'w'),indent=2)
if __name__=='__main__':main()
