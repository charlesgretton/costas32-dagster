import json,random,time
from triple_reduced import ReducedTripleLP
from triple_lp import loadcat, sample
from lp_model import CostasLP
rng=random.Random(880505);cat=loadcat('/mnt/data/costas_independent/costas_12.csv');D,L,tr=sample(cat,5,10,4,rng);out=[];P=CostasLP(12,True)
for label,A in [('dead',D),('live',L)]:
 for p in A:
  lz,lsec,_=P.solve(p)
  t=time.time();M=ReducedTripleLP(12,p);build=time.time()-t;z,sec=M.solve()
  rec={'n':12,'k':5,'label':label,'prefix':list(p),'lp2_status':lz,'lp2_infeasible':lz==2,'triple_status':int(z.status),'triple_infeasible':z.status==2,'build_seconds':build,'solve_seconds':sec,'meta':M.meta};out.append(rec)
  print(label,'lp2',lz,'triple',z.status,'sec',round(sec,2),flush=True)
  json.dump(out,open('/mnt/data/costas_independent/triple_more5.json','w'),indent=2)
