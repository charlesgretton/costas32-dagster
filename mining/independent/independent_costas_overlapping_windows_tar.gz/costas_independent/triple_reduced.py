import json,time,itertools,sys
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

class ReducedTripleLP:
 def __init__(self,n,prefix):
  self.n=n;used=set(prefix);self.dom={i:([prefix[i]] if i<len(prefix) else [r for r in range(n) if r not in used]) for i in range(n)}
  off=0;self.x={}
  for i in range(n):
   for r in self.dom[i]:self.x[i,r]=off;off+=1
  self.y={}
  for i in range(n):
   for j in range(i+1,n):
    for r in self.dom[i]:
     for s in self.dom[j]:
      if r!=s:self.y[i,j,r,s]=off;off+=1
  self.z={}
  for i in range(n):
   for j in range(i+1,n):
    for k in range(j+1,n):
     for r in self.dom[i]:
      for s in self.dom[j]:
       if r==s:continue
       for t in self.dom[k]:
        if t!=r and t!=s:self.z[i,j,k,r,s,t]=off;off+=1
  self.nvar=off;er=[];ec=[];ed=[];be=[];eq=0;ur=[];uc=[];ud=[];bu=[];ub=0
  for i in range(n):
   for r in self.dom[i]:er.append(eq);ec.append(self.x[i,r]);ed.append(1.)
   be.append(1.);eq+=1
  for r in range(n):
   xs=[self.x[i,r] for i in range(n) if (i,r) in self.x]
   for v in xs:er.append(eq);ec.append(v);ed.append(1.)
   be.append(1.);eq+=1
  for i in range(n):
   for j in range(i+1,n):
    for r in self.dom[i]:
     for s in self.dom[j]:
      if r!=s:er.append(eq);ec.append(self.y[i,j,r,s]);ed.append(1.)
     er.append(eq);ec.append(self.x[i,r]);ed.append(-1.);be.append(0.);eq+=1
    for s in self.dom[j]:
     for r in self.dom[i]:
      if r!=s:er.append(eq);ec.append(self.y[i,j,r,s]);ed.append(1.)
     er.append(eq);ec.append(self.x[j,s]);ed.append(-1.);be.append(0.);eq+=1
  for i in range(n):
   for j in range(i+1,n):
    for k in range(j+1,n):
     for r in self.dom[i]:
      for s in self.dom[j]:
       if r==s:continue
       for t in self.dom[k]:
        if t!=r and t!=s:er.append(eq);ec.append(self.z[i,j,k,r,s,t]);ed.append(1.)
       er.append(eq);ec.append(self.y[i,j,r,s]);ed.append(-1.);be.append(0.);eq+=1
     for r in self.dom[i]:
      for t in self.dom[k]:
       if r==t:continue
       for s in self.dom[j]:
        if s!=r and s!=t:er.append(eq);ec.append(self.z[i,j,k,r,s,t]);ed.append(1.)
       er.append(eq);ec.append(self.y[i,k,r,t]);ed.append(-1.);be.append(0.);eq+=1
     for s in self.dom[j]:
      for t in self.dom[k]:
       if s==t:continue
       for r in self.dom[i]:
        if r!=s and r!=t:er.append(eq);ec.append(self.z[i,j,k,r,s,t]);ed.append(1.)
       er.append(eq);ec.append(self.y[j,k,s,t]);ed.append(-1.);be.append(0.);eq+=1
  groups=defaultdict(list)
  for (i,j,r,s),v in self.y.items():groups[j-i,s-r].append(v)
  for vs in groups.values():
   for v in vs:ur.append(ub);uc.append(v);ud.append(1.)
   bu.append(1.);ub+=1
  self.Aeq=coo_matrix((ed,(er,ec)),shape=(eq,off)).tocsr();self.be=np.array(be)
  self.Aub=coo_matrix((ud,(ur,uc)),shape=(ub,off)).tocsr();self.bu=np.array(bu)
  self.meta={'vars':off,'x':len(self.x),'y':len(self.y),'z':len(self.z),'eq':eq,'ub':ub,'eq_nnz':self.Aeq.nnz}
 def solve(self):
  t=time.time();z=linprog(np.zeros(self.nvar),A_ub=self.Aub,b_ub=self.bu,A_eq=self.Aeq,b_eq=self.be,bounds=(0,1),method='highs',options={'presolve':True,'time_limit':90});return z,time.time()-t

def main():
 cases=json.load(open('/mnt/data/costas_independent/lp_results.json'))
 chosen=[]
 for k in [4,5,6]:
  chosen += [x for x in cases if x['n']==12 and x['k']==k and x['label']=='dead' and not x['lp_infeasible']][:2]
  chosen += [x for x in cases if x['n']==12 and x['k']==k and x['label']=='live'][:1]
 # no k4 in prior data; explicit sample from triple script later
 out=[]
 for c in chosen:
  p=c['prefix'];t=time.time();M=ReducedTripleLP(12,p);build=time.time()-t;print('built',c['label'],c['k'],M.meta,'sec',round(build,2),flush=True)
  z,sec=M.solve();o={**c,'triple_status':int(z.status),'triple_infeasible':z.status==2,'build_seconds':build,'solve_seconds':sec,'triple_meta':M.meta};out.append(o)
  print('solved',c['label'],c['k'],z.status,round(sec,2),z.message,flush=True)
  json.dump(out,open('/mnt/data/costas_independent/triple_reduced_results.json','w'),indent=2)
if __name__=='__main__':main()
