import json,random,time
from triple_reduced import ReducedTripleLP
from triple_lp import loadcat, sample
rng=random.Random(991203);cat=loadcat('/mnt/data/costas_independent/costas_12.csv');out=[]
for k,nd,nl in [(4,4,2),(5,10,4),(6,10,4)]:
 D,L,tr=sample(cat,k,nd,nl,rng);print('sample',k,len(D),len(L),'tries',tr,flush=True)
 for label,A in [('dead',D),('live',L)]:
  for p in A:
   t=time.time();M=ReducedTripleLP(12,p);build=time.time()-t;z,sec=M.solve()
   rec={'n':12,'k':k,'label':label,'prefix':list(p),'triple_status':int(z.status),'triple_infeasible':z.status==2,'build_seconds':build,'solve_seconds':sec,'meta':M.meta};out.append(rec)
   print(label,k,p,'status',z.status,'build',round(build,2),'solve',round(sec,2),'vars',M.meta['vars'],flush=True)
   json.dump(out,open('/mnt/data/costas_independent/triple_reduced_batch.json','w'),indent=2)
