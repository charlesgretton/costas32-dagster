#include <algorithm>
#include <cstdint>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;

struct Search {
 int n,w; uint64_t rows=0,nodes=0,leaves=0,full_costas=0; vector<int> p; vector<uint64_t> du;
 vector<uint64_t> depth_nodes; vector<unordered_set<string>> suffix_states;
 Search(int N,int W):n(N),w(W),p(N,-1),du(N,0),depth_nodes(N+1),suffix_states(N+1){}
 string suffix_key(int c){
   int a=max(0,c-(w-1));
   // exact overlap state: relative row pattern of last w-1 columns, plus used rows translated is NOT retained.
   // This key tests the maximum merging available to a purely local window automaton.
   int mn=n;
   for(int i=a;i<c;i++) mn=min(mn,p[i]);
   string s;
   for(int i=a;i<c;i++){s+=to_string(p[i]-mn);s.push_back(',');}
   return s;
 }
 bool global_costas(){
   vector<uint64_t> seen(n,0);
   for(int j=0;j<n;j++)for(int i=0;i<j;i++){
     int d=j-i,e=p[j]-p[i],b=e+n-1;
     if((seen[d]>>b)&1ULL)return false;
     seen[d]|=1ULL<<b;
   }
   return true;
 }
 void dfs(int c){
   nodes++; depth_nodes[c]++;
   if(c>0) suffix_states[c].insert(suffix_key(c));
   if(c==n){leaves++; if(global_costas())full_costas++; return;}
   for(int r=0;r<n;r++) if(!(rows>>r&1ULL)){
     bool ok=true;vector<pair<int,int>> add;
     for(int i=max(0,c-w+1);i<c;i++){
       int d=c-i,e=r-p[i],b=e+n-1;
       if((du[d]>>b)&1ULL){ok=false;break;}
       add.push_back({d,b});
     }
     if(!ok)continue;
     p[c]=r;rows|=1ULL<<r;
     for(auto [d,b]:add)du[d]|=1ULL<<b;
     dfs(c+1);
     for(auto [d,b]:add)du[d]&=~(1ULL<<b);
     rows&=~(1ULL<<r);p[c]=-1;
   }
 }
};
int main(int argc,char**argv){int n=stoi(argv[1]),w=stoi(argv[2]);Search s(n,w);s.dfs(0);
 cout<<"n,window,nodes,leaves,global_costas\n"<<n<<","<<w<<","<<s.nodes<<","<<s.leaves<<","<<s.full_costas<<"\n";
 cout<<"depth,nodes,local_suffix_shapes,merge_ratio\n";
 for(int d=1;d<=n;d++)cout<<d<<","<<s.depth_nodes[d]<<","<<s.suffix_states[d].size()<<","<<(double)s.depth_nodes[d]/max<size_t>(1,s.suffix_states[d].size())<<"\n";
}
