exec(open('/mnt/data/chain_hall_pilot.py').read().split('out=[]')[0])
import random,json,statistics

def local_ok_add(p,r):
 if r in p:return False
 occ={(j-i,p[j]-p[i]) for j in range(len(p)) for i in range(j)};c=len(p)
 return all((c-i,r-a) not in occ for i,a in enumerate(p))
def random_prefix(n,k,rng):
 for _ in range(100000):
  p=[]
  for c in range(k):
   q=[r for r in range(n) if local_ok_add(p,r)]
   if not q:break
   p.append(rng.choice(q))
  if len(p)==k:return tuple(p)
def count(n,pref):
 p=list(pref)+[-1]*(n-len(pref));used=0;m=[0]*n;nodes=0;leaves=0
 for r in pref:used|=1<<r
 for j in range(len(pref)):
  for i in range(j):m[j-i]|=1<<(pref[j]-pref[i]+n-1)
 def dfs(c,u):
  nonlocal nodes,leaves;nodes+=1
  if c==n:leaves+=1;return
  for r in range(n):
   if u>>r&1:continue
   aa=[]
   for i in range(c):
    d=c-i;b=r-p[i]+n-1
    if m[d]>>b&1:break
    aa.append((d,b))
   else:
    p[c]=r
    for d,b in aa:m[d]|=1<<b
    dfs(c+1,u|1<<r)
    for d,b in aa:m[d]&=~(1<<b)
    p[c]=-1
 dfs(len(pref),used);return nodes,leaves
out=[]
for n,k in [(12,6),(12,7),(13,6),(13,7),(14,6),(14,7),(14,8)]:
 rng=random.Random(7000+n*100+k);seen=set();cases=[]
 while len(cases)<20:
  p=random_prefix(n,k,rng)
  if p in seen:continue
  seen.add(p);nn,ll=count(n,p)
  if ll==0 and nn>=5:cases.append((p,nn))
 for p,nn in cases:
  r=summarise_case(n,p);out.append({'n':n,'k':k,'prefix':p,'nodes':nn,**r})
 print(n,k,'mednodes',statistics.median(x[1] for x in cases),'def',sum(x['hall']['def']>0 for x in out if x['n']==n and x['k']==k),'tight',sum(x['hall']['tight']>0 for x in out if x['n']==n and x['k']==k),'unit',sum(x['hall']['unit']>0 for x in out if x['n']==n and x['k']==k),'medrem',statistics.median(x['removed'] for x in out if x['n']==n and x['k']==k),flush=True)
json.dump(out,open('/mnt/data/chain_hall_deeper_results.json','w'),indent=2)
