import json,itertools,statistics
from collections import defaultdict

CASES=json.load(open('/mnt/data/split_learning_results.json'))

def prefix_state(n,p):
    used=set(p); occ=set()
    for j in range(len(p)):
        for i in range(j): occ.add((j-i,p[j]-p[i]))
    return used,occ

def compatible_extension(n,p,assign):
    # assign dict col->row, includes only future columns; verifies row and all displacement uniqueness with prefix and within assign
    vals=list(p)+[-1]*(n-len(p))
    used=set(p)
    for c,r in assign.items():
        if r in used:return False
        used.add(r);vals[c]=r
    occ=set()
    cols=[i for i,v in enumerate(vals) if v>=0]
    for jj,j in enumerate(cols):
        for i in cols[:jj]:
            q=(j-i,vals[j]-vals[i])
            if q in occ:return False
            occ.add(q)
    return True

def col_domains(n,p):
    out={}
    for c in range(len(p),n):
        out[c]=[r for r in range(n) if compatible_extension(n,p,{c:r})]
    for c in range(len(p)):out[c]=[p[c]]
    return out

def build_pair_events(n,p,D):
    # events[(i,j)] = set((a,b)); exact compatibility with prefix for that pair
    ev={}
    for i in range(n):
      for j in range(i+1,n):
        s=set()
        future={c for c in (i,j) if c>=len(p)}
        if not future:
            s.add((p[i],p[j]))
        else:
            for a in D[i]:
              for b in D[j]:
                if a==b:continue
                ass={}
                if i>=len(p):ass[i]=a
                elif a!=p[i]:continue
                if j>=len(p):ass[j]=b
                elif b!=p[j]:continue
                if compatible_extension(n,p,ass):s.add((a,b))
        ev[(i,j)]=s
    return ev

def chain_close(n,p,ev):
    # Repeatedly remove endpoint pair events unsupported through each intermediate column.
    changed=True;removed=0;rounds=0
    while changed:
      changed=False;rounds+=1
      for K in range(2,n):
       for i in range(0,n-K):
        j=i+K; cur=ev[(i,j)]
        if not cur:continue
        keep=set(cur)
        for m in range(i+1,j):
          left=ev[(i,m)];right=ev[(m,j)]
          supported={(a,c) for (a,b) in left for (b2,c) in right if b==b2}
          keep &= supported
          if not keep:break
        if keep!=cur:
          removed += len(cur)-len(keep);ev[(i,j)]=keep;changed=True
      # project removals back to shorter pairs through triples: each event must have support with every outside endpoint? 
      # Avoid this stronger consistency here; endpoint closure alone is sound and matches theorem.
    return removed,rounds

def lag_domains(n,p,ev):
    out={}
    k=len(p)
    usedq={(j-i,p[j]-p[i]) for j in range(k) for i in range(j)}
    for d in range(1,n):
      fam={}
      for i in range(n-d):
        j=i+d
        # resolved prefix positions need no representative; unresolved positions only
        if j<k:continue
        vals={b-a for a,b in ev[(i,j)] if (d,b-a) not in usedq}
        fam[i]=vals
      if fam:out[d]=fam
    return out

def hall_census(fam):
    keys=list(fam);m=len(keys)
    deficiency=[];tight=[];unit=[]
    # all subsets; keep inclusion-minimal deficiency and maximal score later
    for mask in range(1,1<<m):
      E=[keys[t] for t in range(m) if mask>>t&1]
      N=set().union(*(fam[i] for i in E))
      slack=len(N)-len(E)
      rec=(tuple(E),tuple(sorted(N)),slack)
      if slack<0:deficiency.append(rec)
      elif slack==0:tight.append(rec)
      elif slack==1:unit.append(rec)
    return deficiency,tight,unit

def summarise_case(n,p):
    D=col_domains(n,p);ev0=build_pair_events(n,p,D)
    raw=sum(len(v) for v in ev0.values())
    before=lag_domains(n,p,ev0)
    ev={k:set(v) for k,v in ev0.items()}
    rem,rounds=chain_close(n,p,ev)
    after=sum(len(v) for v in ev.values()); fams=lag_domains(n,p,ev)
    cc={'def':0,'tight':0,'unit':0,'lags_def':[],'lags_unit':[],'best_unit':None}
    for d,fam in fams.items():
      de,ti,un=hall_census(fam)
      cc['def']+=len(de);cc['tight']+=len(ti);cc['unit']+=len(un)
      if de:cc['lags_def'].append(d)
      if un:cc['lags_unit'].append(d)
      for E,N,s in un:
        outside=set(fam)-set(E)
        outside_inc=sum(len(fam[j]&set(N)) for j in outside)
        low=sum(1 for i in E if len(fam[i])<=3)
        score=(outside_inc+low)/len(N)
        rec={'lag':d,'E':E,'N':N,'score':score,'outside_inc':outside_inc,'low':low}
        if cc['best_unit'] is None or score>cc['best_unit']['score']:cc['best_unit']=rec
    return {'raw_pair_events':raw,'chain_pair_events':after,'removed':rem,'rounds':rounds,'hall':cc,'domains':{str(d):{str(i):sorted(v) for i,v in f.items()} for d,f in fams.items()}}

out=[]
for z,c in enumerate(CASES):
    n=c['n'];p=tuple(c['prefix']);r=summarise_case(n,p)
    rec={'n':n,'k':c['k'],'prefix':p,'baseline_nodes':c['baseline_nodes'],**r};out.append(rec)
    print(z,n,c['baseline_nodes'],'removed',r['removed'],'def',r['hall']['def'],'tight',r['hall']['tight'],'unit',r['hall']['unit'],'best',None if r['hall']['best_unit'] is None else (r['hall']['best_unit']['lag'],round(r['hall']['best_unit']['score'],2)),flush=True)
json.dump(out,open('/mnt/data/chain_hall_results.json','w'),indent=2)
print('SUMMARY')
for n in [12,13,14]:
 a=[r for r in out if r['n']==n]
 print(n,'N',len(a),'median removed',statistics.median(r['removed'] for r in a),'def cases',sum(r['hall']['def']>0 for r in a),'tight cases',sum(r['hall']['tight']>0 for r in a),'unit cases',sum(r['hall']['unit']>0 for r in a),'median unit count',statistics.median(r['hall']['unit'] for r in a))
