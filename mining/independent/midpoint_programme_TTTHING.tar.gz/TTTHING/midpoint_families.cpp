#include <bits/stdc++.h>
using namespace std;
struct Stat{uint64_t total=0,live=0,arrays=0;};
struct Solver{
 int n,m; vector<int> p; uint64_t rows=0; vector<uint64_t> dm; uint64_t midpoint_count=0,leaves=0;
 unordered_map<string,Stat> A,B,C,D; unordered_set<string> live_mid;
 Solver(int N):n(N),m((int)ceil(.53*N)),p(N,-1),dm(N,0){}
 string midkey(){string s(m,' ');for(int i=0;i<m;i++)s[i]=char(p[i]);return s;}
 vector<string> sigs(){
   int mn=n,mx=-1,lo=0,sum=0; for(int i=0;i<m;i++){mn=min(mn,p[i]);mx=max(mx,p[i]);lo+=p[i]<n/2;sum+=p[i];}
   // normalized coarse placement geometry
   string a=to_string(mn*n/max(1,n-1))+":"+to_string(mx*n/max(1,n-1))+":"+to_string(lo)+":"+to_string(sum/m);
   string b;
   for(int d=1;d<=min(4,m-1);d++){int pos=0,small=0;
     for(int i=0;i<m-d;i++){int e=p[i+d]-p[i];pos+=e>0;small+=abs(e)<=n/4;}
     if(d>1)b+=';';b+=to_string(pos)+","+to_string(small);
   }
   string c;
   for(int d=1;d<=min(3,m-1);d++){int h[3]={0,0,0};
     for(int i=0;i<m-d;i++){int z=abs(p[i+d]-p[i]);int bin=(z<=n/4?0:(z<=n/2?1:2));h[bin]++;}
     if(d>1)c+=';';c+=to_string(h[0])+","+to_string(h[1])+","+to_string(h[2]);
   }
   string dd=a+"|"+b+"|"+c; return {a,b,c,dd};
 }
 void addtot(const vector<string>&s){A[s[0]].total++;B[s[1]].total++;C[s[2]].total++;D[s[3]].total++;}
 void addlive(const vector<string>&s){A[s[0]].live++;B[s[1]].live++;C[s[2]].live++;D[s[3]].live++;}
 void addarray(const vector<string>&s){A[s[0]].arrays++;B[s[1]].arrays++;C[s[2]].arrays++;D[s[3]].arrays++;}
 void dfs(int c, vector<string>* mids=nullptr, string* mk=nullptr){
   vector<string> localS; string localK;
   if(c==m){midpoint_count++;localS=sigs();localK=midkey();addtot(localS);mids=&localS;mk=&localK;}
   if(c==n){leaves++;addarray(*mids);if(live_mid.insert(*mk).second)addlive(*mids);return;}
   for(int r=0;r<n;r++)if(!(rows>>r&1)){
    bool ok=1;vector<pair<int,int>>ad;
    for(int i=0;i<c;i++){int d=c-i,b=r-p[i]+n-1;if((dm[d]>>b)&1){ok=0;break;}ad.push_back({d,b});}
    if(!ok)continue;p[c]=r;rows|=1ULL<<r;for(auto [d,b]:ad)dm[d]|=1ULL<<b;dfs(c+1,mids,mk);for(auto [d,b]:ad)dm[d]&=~(1ULL<<b);rows&=~(1ULL<<r);p[c]=-1;
   }
 }
 void dumpMap(ofstream&f,string name,unordered_map<string,Stat>&M){for(auto &kv:M)f<<name<<"\t"<<kv.first<<"\t"<<kv.second.total<<"\t"<<kv.second.live<<"\t"<<kv.second.arrays<<"\n";}
 void write(){ofstream f("/mnt/data/midpoint_families_"+to_string(n)+".tsv");f<<"scheme\tkey\ttotal\tlive\tarrays\n";dumpMap(f,"A",A);dumpMap(f,"B",B);dumpMap(f,"C",C);dumpMap(f,"D",D);}
};
int main(int ac,char**av){int n=stoi(av[1]);Solver s(n);s.dfs(0);s.write();cerr<<n<<" midpoint "<<s.midpoint_count<<" arrays "<<s.leaves<<" live "<<s.live_mid.size()<<" buckets "<<s.D.size()<<"\n";}
