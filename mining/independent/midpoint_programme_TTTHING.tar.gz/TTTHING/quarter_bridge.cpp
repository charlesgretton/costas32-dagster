#include <bits/stdc++.h>
using namespace std;
struct Rec{uint64_t bridge_nodes=0, midpoint_nodes=0, arrays=0, live_midpoints=0; vector<int> pref;};
struct Solver{
 int n,q,m; vector<int> p; uint64_t rows=0; vector<uint64_t> dm; vector<Rec> recs; unordered_map<string,int> qid; unordered_set<string> live_mid_seen;
 Solver(int N):n(N),q(N/4),m((int)ceil(.53*N)),p(N,-1),dm(N,0){}
 string key(int k){ string s(k,'\0'); for(int i=0;i<k;i++) s[i]=char(p[i]); return s; }
 int getqid(){ string s=key(q); auto it=qid.find(s); if(it!=qid.end()) return it->second; int id=recs.size(); qid.emplace(s,id); Rec r; r.pref.assign(p.begin(),p.begin()+q); recs.push_back(move(r)); return id; }
 void dfs(int c,int active=-1){
   if(c==q) active=getqid();
   if(active>=0 && c>q && c<=m) recs[active].bridge_nodes++;
   if(c==m) recs[active].midpoint_nodes++;
   if(c==n){
      recs[active].arrays++;
      string mk=key(m); string compound=to_string(active)+":"+mk;
      if(live_mid_seen.insert(compound).second) recs[active].live_midpoints++;
      return;
   }
   for(int r=0;r<n;r++) if(!(rows>>r&1)){
      bool ok=true; vector<pair<int,int>> add;
      for(int i=0;i<c;i++){ int d=c-i,b=r-p[i]+n-1; if((dm[d]>>b)&1){ok=false;break;} add.push_back({d,b}); }
      if(!ok) continue;
      p[c]=r; rows|=1ULL<<r; for(auto [d,b]:add) dm[d]|=1ULL<<b;
      dfs(c+1,active);
      for(auto [d,b]:add) dm[d]&=~(1ULL<<b); rows&=~(1ULL<<r); p[c]=-1;
   }
 }
 void write(){
   string fn="/mnt/data/quarter_bridge_"+to_string(n)+".csv"; ofstream f(fn);
   f<<"id,prefix,bridge_nodes,midpoint_nodes,live_midpoints,arrays,used_span,adj_abs_sum,occupied_diffs\n";
   for(int id=0;id<(int)recs.size();id++){
     auto &r=recs[id]; int mn=n,mx=-1,adj=0; set<pair<int,int>> ds;
     for(int i=0;i<q;i++){mn=min(mn,r.pref[i]);mx=max(mx,r.pref[i]);if(i)adj+=abs(r.pref[i]-r.pref[i-1]);for(int j=0;j<i;j++)ds.insert({i-j,r.pref[i]-r.pref[j]});}
     f<<id<<",\"";for(int i=0;i<q;i++){if(i)f<<" ";f<<r.pref[i];}f<<"\","<<r.bridge_nodes<<","<<r.midpoint_nodes<<","<<r.live_midpoints<<","<<r.arrays<<","<<(mx-mn)<<","<<adj<<","<<ds.size()<<"\n";
   }
 }
};
int main(int argc,char**argv){int n=stoi(argv[1]);Solver s(n);s.dfs(0);s.write();cerr<<"n="<<n<<" qprefixes="<<s.recs.size()<<"\n";}
