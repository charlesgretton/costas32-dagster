#include <bits/stdc++.h>
using namespace std;
struct S{
 int n,q,m; vector<int> p; uint64_t rows=0; vector<uint64_t> dm;
 uint64_t nodes=0, qcount=0,mcount=0,leaves=0;
 unordered_set<string> liveq,livem; vector<array<int,4>> sample_dead_m;
 S(int N):n(N),q(N/4),m((int)ceil(.53*N)),p(N,-1),dm(N,0){}
 string key(int k){string s; s.resize(k);for(int i=0;i<k;i++)s[i]=char(p[i]);return s;}
 void dfs(int c){nodes++; if(c==q)qcount++; if(c==m)mcount++; if(c==n){leaves++;liveq.insert(key(q));livem.insert(key(m));return;}
  for(int r=0;r<n;r++)if(!(rows>>r&1)){
   bool ok=1; vector<pair<int,int>> add;
   for(int i=0;i<c;i++){int d=c-i,b=r-p[i]+n-1;if((dm[d]>>b)&1){ok=0;break;}add.push_back({d,b});}
   if(!ok)continue;p[c]=r;rows|=1ULL<<r;for(auto [d,b]:add)dm[d]|=1ULL<<b;dfs(c+1);for(auto [d,b]:add)dm[d]&=~(1ULL<<b);rows&=~(1ULL<<r);p[c]=-1;
  }
 }
};
int main(int ac,char**av){int n=stoi(av[1]);S s(n);s.dfs(0);cout<<"n "<<n<<" q "<<s.q<<" m "<<s.m<<" nodes "<<s.nodes<<" qfront "<<s.qcount<<" mfront "<<s.mcount<<" arrays "<<s.leaves<<" liveq "<<s.liveq.size()<<" livem "<<s.livem.size()<<"\n";
 string fn="/mnt/data/qm_"+to_string(n)+".txt";ofstream f(fn);f<<n<<" "<<s.q<<" "<<s.m<<" "<<s.qcount<<" "<<s.mcount<<" "<<s.leaves<<" "<<s.liveq.size()<<" "<<s.livem.size()<<"\n";for(auto &x:s.liveq){for(unsigned char c:x)f<<int(c)<<",";f<<"\n";}
}
