import json,statistics
D=json.load(open('/mnt/data/chain_hall_deeper_results.json'))

def count_branch(n,pref,lag,E,N,omit):
    required=set(N)-{omit}; E=set(E)
    p=list(pref)+[-1]*(n-len(pref));used=0;m=[0]*n;nodes=0;leaves=0;closures=0
    for r in pref:used|=1<<r
    for j in range(len(pref)):
      for i in range(j):m[j-i]|=1<<(pref[j]-pref[i]+n-1)
    def check_resolved(c):
      nonlocal closures
      seenE=set()
      for i in range(n-lag):
       j=i+lag
       if j>=c:continue
       e=p[j]-p[i]
       if i in E:
        if e not in required:closures+=1;return False
        seenE.add(e)
       elif e in required:
        closures+=1;return False
      # all resolved required resources unique already by Costas; if E fully resolved need exact set
      if all(i+lag<c for i in E) and seenE!=required:closures+=1;return False
      return True
    def dfs(c,u):
      nonlocal nodes,leaves;nodes+=1
      if not check_resolved(c):return
      if c==n:leaves+=1;return
      for r in range(n):
       if u>>r&1:continue
       aa=[]
       for i in range(c):
        d=c-i;b=r-p[i]+n-1
        if m[d]>>b&1:break
        aa.append((d,b))
       else:
        p[c]=r
        for d,b in aa:m[d]|=1<<b
        dfs(c+1,u|1<<r)
        for d,b in aa:m[d]&=~(1<<b)
        p[c]=-1
    dfs(len(pref),used);return nodes,leaves,closures

out=[]
for r in D:
 b=r['hall']['best_unit']
 if not b or r['nodes']<10:continue
 branches=[]
 for omit in b['N']:
  nn,ll,cc=count_branch(r['n'],r['prefix'],b['lag'],b['E'],b['N'],omit)
  branches.append({'omit':omit,'nodes':nn,'leaves':ll,'closures':cc})
 ratio=(sum(x['nodes'] for x in branches)+1)/r['nodes']
 out.append({'n':r['n'],'k':r['k'],'prefix':r['prefix'],'baseline_nodes':r['nodes'],'lag':b['lag'],'E':b['E'],'N':b['N'],'score':b['score'],'branches':branches,'ratio_total':ratio,'ratio_max':max(x['nodes'] for x in branches)/r['nodes']})
 print(r['n'],r['k'],r['nodes'],'lag',b['lag'],'branches',len(branches),'ratio',round(ratio,3),'max',round(out[-1]['ratio_max'],3),flush=True)
json.dump(out,open('/mnt/data/unit_slack_split_results.json','w'),indent=2)
print('SUMMARY',len(out))
for key in sorted(set((x['n'],x['k']) for x in out)):
 a=[x for x in out if (x['n'],x['k'])==key]
 print(key,'N',len(a),'medtotal',statistics.median(x['ratio_total'] for x in a),'min',min(x['ratio_total'] for x in a),'<=.8',sum(x['ratio_total']<=.8 for x in a),'medmax',statistics.median(x['ratio_max'] for x in a))
