# Order-32 Costas public release: Cell 3

This release supports the computer-assisted theorem that no transpose-symmetric
Costas permutation of order 32 lies in branch `Z=1T, f=2`.

Scope: this does not settle unrestricted order 32 or the complete
transpose-symmetric order-32 problem. It closes the third of six `Z=1` cells.

See `cell3_public_release/REPORT.pdf` for the self-contained proof, audit gates,
complete census profile, reproduction protocol, campaign status, and future work.

## Verify the archived results

```bash
sha256sum cell3_public_release/results.tar.gz
mkdir verification
cd verification
tar -xzf ../cell3_public_release/results.tar.gz
cd results
sha256sum -c ../../cell3_public_release/results_final_manifest.sha256
```
